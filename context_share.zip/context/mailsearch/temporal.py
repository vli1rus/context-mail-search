import re
from datetime import date, timedelta


def relative_range(query, as_of):
    """Infer likely received dates. The caller uses them as soft evidence."""
    if not as_of:
        return '', ''
    current = date.fromisoformat(as_of)
    query = query.lower().replace('ё', 'е')
    def span(first, last):
        return first.isoformat(), last.isoformat()

    if re.search(r'\b(?:позавчера|позавчерашн\w*)\b', query):
        target = current - timedelta(days=2)
        return span(target, target)
    if re.search(r'\b(?:вчера|вчерашн\w*)\b', query):
        target = current - timedelta(days=1)
        return span(target, target)
    if re.search(r'\b(?:сегодня|сегодняшн\w*)\b', query):
        return span(current, current)
    recent = re.search(r'\b(?:за\s+)?последн\w*\s+(\d{1,3})\s+(день|дня|дней|недел\w*)\b', query)
    if recent and int(recent[1]):
        days = int(recent[1]) * (7 if recent[2].startswith('недел') else 1)
        return span(current - timedelta(days=days - 1), current)
    if re.search(r'\bна\s+(?:прошлой|этой)\s+неделе\b', query):
        monday = current - timedelta(days=current.weekday())
        return span(monday - timedelta(days=7), monday - timedelta(days=1)) if 'прошлой' in query else span(monday, current)
    if re.search(r'\bв\s+(?:прошлом|этом)\s+месяце\b', query):
        first = current.replace(day=1)
        if 'прошлом' in query:
            last = first - timedelta(days=1)
            return span(last.replace(day=1), last)
        return span(first, current)
    return '', ''
